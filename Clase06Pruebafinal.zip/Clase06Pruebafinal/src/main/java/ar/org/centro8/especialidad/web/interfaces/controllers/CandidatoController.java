package ar.org.centro8.especialidad.web.interfaces.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ar.org.centro8.especialidad.web.interfaces.entities.Candidato;
import ar.org.centro8.especialidad.web.interfaces.repositories.CandidatoRepository;


@Controller
public class CandidatoController {

    @Autowired
    CandidatoRepository cr;


  
    @GetMapping("/candidato")
    public String getCandidato(){

       return "candidato";     
    }
    @PostMapping("/candidato2")
        public String guardarcandidato(@ModelAttribute Candidato can){
            cr.save(can);
            return "candidato";
        }
    
}   
