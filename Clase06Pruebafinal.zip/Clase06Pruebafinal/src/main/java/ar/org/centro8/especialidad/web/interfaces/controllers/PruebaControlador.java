package ar.org.centro8.especialidad.web.interfaces.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ar.org.centro8.especialidad.web.interfaces.entities.Prueba;
import ar.org.centro8.especialidad.web.interfaces.repositories.pruebaRepository;
@Controller
public class PruebaControlador {
    @Autowired
    pruebaRepository pru;

    @GetMapping("/prueba")
    public String getPrueba(){
        
        return "prueba";
    }
    
    @PostMapping("/prueba2")
    public String guardarDatos(@ModelAttribute Prueba pr) {
        pru.save(pr);
        return "prueba"; // Redirigir a una página de éxito o a donde desees
    }
}
