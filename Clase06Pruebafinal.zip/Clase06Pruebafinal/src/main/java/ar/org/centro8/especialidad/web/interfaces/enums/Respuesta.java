package ar.org.centro8.especialidad.web.interfaces.enums;

public enum Respuesta {
    s,
    n
}
