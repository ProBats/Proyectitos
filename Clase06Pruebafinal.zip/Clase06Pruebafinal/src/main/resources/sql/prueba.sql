create database prueba;
use prueba;
create table prueba(
nombre varchar(100),
email varchar(100),
id int auto_increment primary key
);
