package ar.org.centro8.curso.especialidad.aplicaciones.web.enums;

public enum Turno {
	MAÑANA,
	TARDE,
	NOCHE
}
