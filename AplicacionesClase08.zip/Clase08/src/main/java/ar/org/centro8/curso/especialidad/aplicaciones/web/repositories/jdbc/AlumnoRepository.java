package ar.org.centro8.curso.especialidad.aplicaciones.web.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.especialidad.aplicaciones.web.connectors.Connector;
import ar.org.centro8.curso.especialidad.aplicaciones.web.entities.Alumno;
import ar.org.centro8.curso.especialidad.aplicaciones.web.entities.Curso;
import ar.org.centro8.curso.especialidad.aplicaciones.web.enums.Dia;
import ar.org.centro8.curso.especialidad.aplicaciones.web.enums.Turno;
import ar.org.centro8.curso.especialidad.aplicaciones.web.repositories.interfaces.I_AlumnoRepository;

public class AlumnoRepository implements I_AlumnoRepository{
	
	Connection conn=Connector.getConnection();
	
	@Override
	public void save(Alumno alumno) {
		if(alumno==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into cursos (nombre, apellido, edad, curso) values (?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS
        )) {
            ps.setString(1, alumno.getNombre());
            ps.setString(2, alumno.getApellido());
            ps.setInt(3, alumno.getEdad());
            ps.setString(4, alumno.getCurso().toString());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) alumno.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
	}

	@Override
	public void remove(Alumno alumno) {
		if(alumno==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from alumnos where id=?")) {
            ps.setInt(1, alumno.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(3);
        }
	}

	@Override
	public void update(Alumno alumno) {
		if(alumno==null) return;
		
	}

	@Override
	public List<Alumno> getAll() {
		List<Alumno>lista=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from alumnos")) {
            while(rs.next()){
                lista.add(new Alumno(
                    rs.getInt("id"), 
                    rs.getString("nombre"), 
                    rs.getString("apellido"), 
                    rs.getString("edad"),
                    rs.getInt("idCurso");

                    // Ahora necesitas obtener la información del curso asociado
                    Curso curso = getCursoById(curso);

                    lista.add(new Alumno(id, nombre, apellido, edad, curso));
                }
            } catch (Exception e) {
                System.out.println(e);
            }
            return lista;
	}
	
	private Curso getCursoById(int idCurso) {
	    try (ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM cursos WHERE id = " + idCurso)) {
	        if (rs.next()) {
	            int id = rs.getInt("id");
	            String titulo = rs.getString("titulo");
	            String profesor = rs.getString("profesor");
	            Dia dia = Dia.valueOf(rs.getString("dia"));
	            Turno turno = Turno.valueOf(rs.getString("turno"));
	            return new Curso(id, titulo, profesor, dia, turno);
	        }
	    } catch (Exception e) {
	        System.out.println(e);
	    }
	    return null;

}
