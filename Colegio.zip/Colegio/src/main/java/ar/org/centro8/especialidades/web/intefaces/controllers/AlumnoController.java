package ar.org.centro8.especialidades.web.intefaces.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import ar.org.centro8.especialidades.web.intefaces.entities.Alumno;
import ar.org.centro8.especialidades.web.intefaces.entities.Curso;
import ar.org.centro8.especialidades.web.intefaces.repositories.AlumnosRepository;
import ar.org.centro8.especialidades.web.intefaces.repositories.CursosRepository;

@Controller
public class AlumnoController {
    private String mensaje="Ingrese los datos del curso a registrar";
    @Autowired
    AlumnosRepository ar;

    @Autowired
    CursosRepository cr;

    //Pagina Cursos
    @GetMapping("/alumnos")
    public String getAlumnos(Model model){
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("alumnos", new Alumno());
        model.addAttribute("all", ((List<Alumno>)ar.findAll()));
        model.addAttribute("cursos", ((List<Curso>)cr.findAll()));
        return"alumnos";
    }
    
     @PostMapping("/saveAlumno")
    public String guardarAlumno(@ModelAttribute Alumno alumno){
        ar.save(alumno);
        if (alumno.getId()>=0) {
            mensaje="Se guardo el Alumno "+alumno.getId();
        }else{
            mensaje="No se pudo Guardar el Alumno";
        }
        return "redirect:alumnos";
    }

    @RequestMapping("/eliminarAlumno/{id}")
    public String eliminarAlumno(@PathVariable int id){
        ar.deleteById(id);
        return "redirect:/alumnos";
    }
}
