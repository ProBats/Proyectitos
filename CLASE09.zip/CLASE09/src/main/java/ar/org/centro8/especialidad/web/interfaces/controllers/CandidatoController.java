package ar.org.centro8.especialidad.web.interfaces.controllers;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ar.org.centro8.especialidad.web.interfaces.entities.Candidato;
import ar.org.centro8.especialidad.web.interfaces.repositories.CandidatoRepository;


@Controller
public class CandidatoController {

    private String mensaje="Ingrese sus datos personales para postularse";

    /*Por si tengo check box en */
    /*private boolean primario = false;
    private boolean secundario = false;
    private boolean terciario = false;
    private boolean universitario = false;*/

    @Autowired
    CandidatoRepository cr;


  
    @GetMapping("/candidato")
    public String getCandidato(Model model){
            model.addAttribute("mensaje", mensaje);
            model.addAttribute("candidato", new Candidato());
           /* model.addAttribute("primario", primario);
            model.addAttribute("secundario", secundario);
            model.addAttribute("terciario", terciario);
            model.addAttribute("universitario", universitario); */
       return "candidato";     
    }
    @PostMapping("/save")
        public String guardarcandidato(@ModelAttribute Candidato candidato){
            try {
                
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
                Date fecha = sdf.parse("2010-01-02"); 
                Date fe = sdf.parse(candidato.getFenaci());
                if (fe.before(fecha)) {
                    cr.save(candidato);
                    if(candidato.getId()>=0){
                        mensaje="Se guardo el candidato "+candidato.getId();
                    }else{
                        mensaje="No se pudo guardar el candidator!";
                    }
                    
                } else {
                    mensaje= "No se pudo postular porque es Menor de EDAD!!!";
                }
            } catch (ParseException e) {
                System.out.println("Error al parsear la fecha: " + e.getMessage());
            }
            return "redirect:candidato";
            
        }
    
}   
